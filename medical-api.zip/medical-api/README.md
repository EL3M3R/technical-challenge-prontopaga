# Medical API - Proyecto Pronto Paga

API desarrollada con **NestJS** para gestionar usuarios, autenticación, citas y pagos. Incluye autenticación con JWT y documentación con Swagger.

---

## 🚀 Requisitos

- **Node.js** (v16 o superior): [Descargar Node.js](https://nodejs.org/)
- **npm** (incluido con Node.js) o **yarn**
- **PostgreSQL** (o cualquier base de datos compatible con TypeORM)

---

## 🛠️ Instalación

1. Clona el repositorio:
   ```bash
   git clone https://github.com/your-username/medical-api.git
   cd medical-api
   npm install
   ```
2. Crea un archivo .env en la raíz del proyecto con las siguientes variables:

   ````bash
   DATABASE_HOST=localhost
   DATABASE_PORT=5432
   DATABASE_USER=your_user
   DATABASE_PASSWORD=your_password
   DATABASE_NAME=medical_api
   JWT_SECRET=your_jwt_secret
   PORT=3000
   ```

   ````

3. Ejecuta las migraciones para configurar la base de datos:

```bash
npm run typeorm:migration:run
```

4. Inicia el servidor:

```bash
npm run start:dev
```

## 📖 Documentación

Accede a la documentación de la API en Swagger visitando:

```URL
   http://localhost:3000/api/docs
```

## 📂 Estructura del proyecto

src/
├── app.module.ts # Módulo raíz
├── main.ts # Punto de entrada de la aplicación
│
├── auth/ # Módulo de autenticación
├── users/ # Módulo de usuarios
├── appointments/ # Módulo de citas
├── payments/ # Módulo de pagos
│
└── common/ # Lógica compartida (guards, filters, interceptors)

---

### 🔹 **Explicación:**

- **`src/`** → Contiene todo el código fuente de la API.
- **`auth/`** → Módulo de autenticación con JWT y validación de roles.
- **`users/`** → Gestión de usuarios y roles.
- **`appointments/`** → Módulo de citas médicas.
- **`payments/`** → Lógica de pagos y facturación.
- **`common/`** → Código reutilizable (**guards, filtros e interceptores**).
- **`config/`** → Configuración de la aplicación y variables de entorno.
- **`test/`** → Contiene las pruebas unitarias y de integración.
- **`.env.example`** → Archivo de ejemplo para configuración con variables de entorno.
- **`docker-compose.yml`** → Configuración de Docker para ejecutar la API.

---

Este formato permite una **visualización clara y estructurada** en Markdown. 🚀 Puedes copiarlo directamente en tu `README.md`.
