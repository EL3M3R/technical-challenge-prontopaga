import { Injectable, UnauthorizedException } from '@nestjs/common';
import { AuthGuard } from '@nestjs/passport';

@Injectable()
export class JwtAuthGuard extends AuthGuard('jwt') {
  handleRequest(err, user, info) {
    console.log('info', info);
    console.warn('user', user);
    if (err || !user) {
      throw new UnauthorizedException('Token inválido o no proporcionado');
    }
    return user;
  }
}
