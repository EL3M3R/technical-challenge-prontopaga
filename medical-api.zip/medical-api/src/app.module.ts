import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { ConfigModule } from '@nestjs/config';
import { typeOrmConfig } from './config/typeorm.config';
import { PaymentController } from './payments/controllers/payment.controller';
import { AppointmentController } from './appointments/controllers/appointment.controller';
import { UserModule } from './users/users.module';
import { AppointmentModule } from './appointments/appointments.module';
import { PaymentsModule } from './payments/payments.module';
import { AuthModule } from './auth/auth.module';
import { JwtStrategy } from './jwt-strategy/jwt-strategy';

@Module({
  imports: [
    ConfigModule.forRoot({ isGlobal: true }),
    TypeOrmModule.forRootAsync(typeOrmConfig),
    UserModule,
    AppointmentModule,
    PaymentsModule,
    AuthModule,
  ],
  controllers: [AppointmentController, PaymentController],
  providers: [JwtStrategy],
})
export class AppModule {}
