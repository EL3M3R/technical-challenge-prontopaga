import { Repository } from 'typeorm';
import { Appointment, AppointmentStatus } from '../entities/appointment.entity';
import { InjectRepository } from '@nestjs/typeorm';

export class AppointmentRepository {
  constructor(
    @InjectRepository(Appointment)
    private readonly appointmentRepository: Repository<Appointment>,
  ) {}

  async createAndSave(appointment: Appointment) {
    const newAppointment = this.appointmentRepository.create(appointment);
    return this.appointmentRepository.save(newAppointment);
  }

  async existingAppointment(date: string, time: string, doctorId: string) {
    return this.appointmentRepository.findOne({
      where: { date, time, doctor: { id: doctorId } },
    });
  }

  async findAppointmentById(appointmentId: string) {
    return this.appointmentRepository.findOne({
      where: { id: appointmentId },
      relations: ['doctor'],
    });
  }

  async findAppointmentToday(doctorId: string, today: string) {
    return this.appointmentRepository.find({
      where: {
        doctor: { id: doctorId },
        date: today,
        status: AppointmentStatus.CONFIRMED,
      },
      relations: ['patient', 'payment'],
    });
  }

  async findAppointmentByIdAndStatus(
    appointmentId: string,
    status: AppointmentStatus,
  ) {
    return this.appointmentRepository.findOne({
      where: { id: appointmentId, status },
    });
  }

  async findPatientAppointments(patientId: string) {
    return this.appointmentRepository.find({
      where: { patient: { id: patientId } },
      relations: ['doctor', 'payment'],
      order: { date: 'DESC', time: 'ASC' },
    });
  }
}
