import {
  BadRequestException,
  forwardRef,
  Inject,
  Injectable,
  NotFoundException,
} from '@nestjs/common';
import { Appointment, AppointmentStatus } from '../entities/appointment.entity';
import { CreateAppointmentDto } from '../dto/create-appointment.dto';
import { UserRepository } from 'src/users/repositories/user.repository';
import { AppointmentRepository } from '../repositories/appointment.repository';
import { PaymentStatus } from 'src/payments/entities/payment.entity';
import { PaymentService } from 'src/payments/services/payment.service';

@Injectable()
export class AppointmentService {
  constructor(
    private readonly appointmentRepository: AppointmentRepository,
    private readonly userRepository: UserRepository,
    @Inject(forwardRef(() => PaymentService))
    private readonly paymentService: PaymentService,
  ) {}

  async create(createAppointmentDto: CreateAppointmentDto, patientId: string) {
    const patient = await this.userRepository.findPatientById(patientId);

    if (!patient || patient.role !== 'patient') {
      throw new BadRequestException('Patient not found');
    }

    const { doctorId, time, date } = createAppointmentDto;

    const doctor = await this.userRepository.findDoctorById(doctorId);

    if (!doctor || doctor.role !== 'doctor') {
      throw new BadRequestException('Doctor not found');
    }

    if (!this.isTimeWithinAllowedRange(time)) {
      throw new BadRequestException(
        'Appointment time must be between 07:00-12:00 or 14:00-18:00.',
      );
    }

    const existingAppointment =
      await this.appointmentRepository.existingAppointment(
        date,
        time,
        doctorId,
      );

    if (existingAppointment) {
      throw new BadRequestException('This time slot is already booked.');
    }

    const newAppointment = new Appointment();
    newAppointment.date = createAppointmentDto.date;
    newAppointment.time = createAppointmentDto.time;
    newAppointment.doctor = doctor;
    newAppointment.patient = patient;

    return await this.appointmentRepository.createAndSave(newAppointment);
  }

  async payAppointment(
    appointmentId: string,
    patientId: string,
    amount: number,
  ) {
    const appointment =
      await this.appointmentRepository.findAppointmentByIdAndStatus(
        appointmentId,
        AppointmentStatus.PENDING,
      );

    if (!appointment) {
      throw new BadRequestException('Appointment not found');
    }

    const patient = await this.userRepository.findPatientById(patientId);

    if (!patient || patient.role !== 'patient') {
      throw new BadRequestException('Patient not found');
    }

    const paymentIntent = await this.paymentService.createPaymentIntent(
      amount,
      'PEN',
      patient.id,
      appointment.id,
    );

    return paymentIntent;
  }

  async completePayment(appointmentId: string, patientId: string) {
    const appointment =
      await this.appointmentRepository.findAppointmentByIdAndStatus(
        appointmentId,
        AppointmentStatus.PENDING,
      );

    console.log('appointment', appointment);
    if (!appointment || appointment.status !== AppointmentStatus.PENDING) {
      throw new BadRequestException('Appointment not due for payment');
    }

    const patient = await this.userRepository.findPatientById(patientId);
    console.log('patient', patient);

    if (!patient || patient.role !== 'patient') {
      throw new BadRequestException('Patient not found');
    }

    appointment.status = AppointmentStatus.PAID;
    const appointmentSave =
      await this.appointmentRepository.createAndSave(appointment);

    const payment =
      await this.paymentService.getPaymentByAppointmentId(appointmentId);
    payment.status = PaymentStatus.COMPLETED;
    console.log('payment', payment);

    const payUpdate = await this.paymentService.updatePayment(payment);
    console.log('payUpdate', payUpdate);
    console.log('payUpdate', payUpdate);
    return {
      ...appointmentSave,
      patient: {
        id: patient.id,
        fullName: patient.fullName,
        email: patient.email,
      },
    };
  }

  async getAppointmentById(appointmentId: string) {
    return this.appointmentRepository.findAppointmentById(appointmentId);
  }

  async updateAppointment(appointment: Appointment) {
    return this.appointmentRepository.createAndSave(appointment);
  }

  async updateAppointmentStatus(
    appointmentId: string,
    status: AppointmentStatus,
  ): Promise<Appointment> {
    const appointment =
      await this.appointmentRepository.findAppointmentById(appointmentId);

    if (!appointment) {
      throw new NotFoundException('Cita no encontrada');
    }

    if (appointment.status !== AppointmentStatus.PAID) {
      throw new BadRequestException(
        'Solo se pueden confirmar/rechazar citas pagadas',
      );
    }

    appointment.status = status;
    return this.appointmentRepository.createAndSave(appointment);
  }

  async getTodayAppointments(doctorId: string): Promise<Appointment[]> {
    const today = new Date().toISOString().split('T')[0];
    return this.appointmentRepository.findAppointmentToday(doctorId, today);
  }

  async getPatientAppointments(patientId: string): Promise<Appointment[]> {
    return this.appointmentRepository.findPatientAppointments(patientId);
  }

  /**
   * @description Verifica si la hora de la cita está dentro del rango permitido
   * @param time
   * @returns
   */
  private isTimeWithinAllowedRange(time: string): boolean {
    const [hours, minutes] = time.split(':').map(Number);
    const totalMinutes = hours * 60 + minutes;

    const morningStart = 7 * 60; // 07:00
    const morningEnd = 12 * 60; // 12:00
    const afternoonStart = 14 * 60; // 14:00
    const afternoonEnd = 18 * 60; // 18:00

    return (
      (totalMinutes >= morningStart && totalMinutes <= morningEnd) ||
      (totalMinutes >= afternoonStart && totalMinutes <= afternoonEnd)
    );
  }
}
