import {
  Body,
  Controller,
  Get,
  Param,
  Patch,
  Post,
  Query,
  UseGuards,
} from '@nestjs/common';
import { CreateAppointmentDto } from '../dto/create-appointment.dto';
import { AppointmentService } from '../services/appointment.service';
import { AppointmentStatus } from '../entities/appointment.entity';
import { JwtAuthGuard } from 'src/auth/guards/jwt-auth/jwt-auth.guard';
import { Roles } from 'src/auth/decorators/roles.decorator';
import { RolesGuard } from 'src/auth/guards/roles.guard';
import { UserRole } from 'src/users/entities/user.entity';
import { ApiOperation, ApiParam, ApiResponse, ApiTags } from '@nestjs/swagger';

@ApiTags('Appointments')
@Controller('appointment')
export class AppointmentController {
  constructor(private readonly appointmentService: AppointmentService) {}

  @UseGuards(JwtAuthGuard, RolesGuard)
  @Roles(UserRole.PATIENT)
  @Post('create/:patientId')
  @ApiOperation({ summary: 'Crear una nueva cita' })
  @ApiResponse({ status: 201, description: 'Cita creada exitosamente' })
  @ApiResponse({ status: 400, description: 'Datos inválidos' })
  async createAppointment(
    @Body() createAppointmentDto: CreateAppointmentDto,
    @Param('patientId') patientId: string,
  ) {
    return this.appointmentService.create(createAppointmentDto, patientId);
  }

  @UseGuards(JwtAuthGuard)
  @Post('pay/:appointmentId/:patientId/:amount')
  @ApiOperation({ summary: 'Obtener una cita por ID' })
  @ApiParam({
    name: 'appointmentId',
    description: 'ID de la cita',
    example: 'f2e24274-81e1-43b2-a066-4dc7508586b4',
  })
  @ApiResponse({ status: 200, description: 'Cita encontrada' })
  @ApiResponse({ status: 404, description: 'Cita no encontrada' })
  async payAppointment(
    @Param('appointmentId') appointmentId: string,
    @Param('patientId') patientId: string,
    @Param('amount') amount: number,
  ) {
    const paymentIntent = await this.appointmentService.payAppointment(
      appointmentId,
      patientId,
      amount,
    );

    return {
      success: true,
      message: 'Payment intent created successfully',
      data: {
        url: paymentIntent.url,
      },
    };
  }

  @UseGuards(JwtAuthGuard, RolesGuard)
  @Roles(UserRole.DOCTOR)
  @Patch(':id/status')
  @ApiOperation({ summary: 'Actualiza el estado de la cita' })
  @ApiParam({
    name: 'id',
    description: 'ID de la cita',
    example: 'f2e24274-81e1-43b2-a066-4dc7508586b4',
  })
  @ApiParam({
    name: 'status',
    description: 'Nuevo estado de la cita',
    example: 'COMPLETED',
  })
  @ApiResponse({ status: 200, description: 'Actualiza el estado de una cita' })
  @ApiResponse({ status: 404, description: 'Cita no encontrada' })
  async updateAppointmentStatus(
    @Param('id') id: string,
    @Query('status') status: AppointmentStatus,
  ) {
    return this.appointmentService.updateAppointmentStatus(id, status);
  }

  @UseGuards(JwtAuthGuard, RolesGuard)
  @Roles(UserRole.DOCTOR)
  @Get('doctor/today')
  @ApiOperation({ summary: 'Obtener citas del doctor para hoy' })
  @ApiResponse({ status: 200, description: 'Citas encontradas' })
  @ApiResponse({ status: 404, description: 'No se encontraron citas' })
  @ApiParam({
    name: 'doctorId',
    description: 'ID del doctor',
    example: 'f2e24274-81e1-43b2-a066-4dc7508586b4',
  })
  async getDoctorAppointmentsToday(@Query('doctorId') doctorId: string) {
    return this.appointmentService.getTodayAppointments(doctorId);
  }

  @UseGuards(JwtAuthGuard, RolesGuard)
  @Roles(UserRole.DOCTOR)
  @Get('patient/history/:patientId')
  @ApiOperation({ summary: 'Obtener historial de citas del paciente' })
  @ApiParam({
    name: 'patientId',
    description: 'ID del paciente',
    example: 'f2e24274-81e1-43b2-a066-4dc7508586b4',
  })
  @ApiResponse({ status: 200, description: 'Historial de citas encontrado' })
  @ApiResponse({ status: 404, description: 'No se encontraron citas' })
  @ApiResponse({ status: 403, description: 'Acceso denegado' })
  @ApiResponse({ status: 500, description: 'Error interno del servidor' })
  async getPatientHistory(@Param('patientId') patientId: string) {
    return this.appointmentService.getPatientAppointments(patientId);
  }
}
