import { Controller, Get, Query } from '@nestjs/common';
import { ApiOperation, ApiParam, ApiResponse, ApiTags } from '@nestjs/swagger';
import { PaymentService } from 'src/payments/services/payment.service';

@ApiTags('Payments')
@Controller('payment')
export class PaymentController {
  constructor(private readonly paymentService: PaymentService) {}

  @Get('pay/success')
  @ApiOperation({
    summary:
      'Recibe los detalles de la sesión de pago después de un pago exitoso',
  })
  @ApiResponse({
    status: 200,
    description: 'El pago fue exitoso',
    type: Object,
  })
  @ApiResponse({
    status: 400,
    description: 'Bad request',
  })
  @ApiParam({
    name: 'session_id',
    required: true,
    description: 'ID de la sesión de pago',
  })
  @ApiParam({
    name: 'patientId',
    required: true,
    description: 'ID del paciente',
  })
  @ApiParam({
    name: 'appointmentId',
    required: true,
    description: 'ID de la cita',
  })
  async paySuccess(
    @Query('session_id') sessionId: string,
    @Query('patientId') patientId: string,
    @Query('appointmentId') appointmentId: string,
  ) {
    const { patient, date } =
      await this.paymentService.getPaymentSessionDetails(
        sessionId,
        patientId,
        appointmentId,
      );

    return {
      success: true,
      message: 'Pago exitoso',
      data: {
        customer_details: {
          name: patient.fullName,
          email: patient.email,
        },
        date,
      },
    };
  }
}
