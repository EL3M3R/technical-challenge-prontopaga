import {
  BadRequestException,
  forwardRef,
  Inject,
  Injectable,
} from '@nestjs/common';
import { ConfigService } from '@nestjs/config';
import { AppointmentService } from 'src/appointments/services/appointment.service';
import { Payment } from 'src/payments/entities/payment.entity';
import { PaymentRepository } from 'src/payments/repositories/payment.repository';
import Stripe from 'stripe';

@Injectable()
export class PaymentService {
  private stripe: Stripe;

  constructor(
    private configService: ConfigService,
    @Inject(forwardRef(() => AppointmentService))
    private readonly appointmentService: AppointmentService,
    private readonly PaymentRepository: PaymentRepository,
  ) {
    this.stripe = new Stripe(
      this.configService.get<string>('STRIPE_SECRET_KEY'),
    );
  }

  async createPaymentIntent(
    amount: number,
    currency: string,
    patientId: string,
    appointmentId: string,
  ) {
    try {
      const domainURL = 'http://localhost:3000';

      const paymentIntent = await this.stripe.checkout.sessions.create({
        mode: 'payment',
        payment_method_types: ['card'],
        line_items: [
          {
            price_data: {
              currency: currency,
              product_data: {
                name: 'Medical Consultation',
                description: 'Consultation with a doctor',
              },
              unit_amount: Math.round(amount * 100),
            },
            quantity: 1,
          },
        ],
        success_url: `${domainURL}/payment/pay/success?session_id={CHECKOUT_SESSION_ID}&patientId=${patientId}&appointmentId=${appointmentId}`,
        cancel_url: 'http://localhost:3000/payment/pay/cancel',
      });

      const paymentModel = new Payment();
      paymentModel.amount = amount;
      paymentModel.paymentMethod = 'card';
      paymentModel.appointment =
        await this.appointmentService.getAppointmentById(appointmentId);

      const payment_ = await this.PaymentRepository.createPayment(paymentModel);
      console.log('payment_', payment_);

      const appointment =
        await this.appointmentService.getAppointmentById(appointmentId);

      appointment.payment = payment_;
      const appointmentUpdate =
        await this.appointmentService.updateAppointment(appointment);
      console.log('appointmentUpdate', appointmentUpdate);
      return paymentIntent;
    } catch (error) {
      throw new Error(`Error creating payment intent: ${error.message}`);
    }
  }

  async getPaymentSessionDetails(
    sessionId: string,
    patientId: string,
    appointmentId: string,
  ) {
    try {
      const session = await this.stripe.checkout.sessions.retrieve(sessionId);
      if (session.payment_status === 'paid') {
        const appointment = await this.appointmentService.completePayment(
          appointmentId,
          patientId,
        );

        return appointment;
      } else {
        throw new BadRequestException('Payment not completed');
      }
    } catch (error) {
      throw new Error(`Error retrieving payment session: ${error.message}`);
    }
  }

  async updatePayment(payment: Payment) {
    return this.PaymentRepository.createPayment(payment);
  }

  async getPaymentByAppointmentId(appointmentId: string) {
    return this.PaymentRepository.getPaymentById(appointmentId);
  }
}
