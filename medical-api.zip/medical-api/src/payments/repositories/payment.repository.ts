import { Repository } from 'typeorm';
import { Payment } from '../entities/payment.entity';
import { InjectRepository } from '@nestjs/typeorm';

export class PaymentRepository {
  constructor(
    @InjectRepository(Payment)
    private readonly paymentRepository: Repository<Payment>,
  ) {}

  async createPayment(payment: Payment): Promise<Payment> {
    const newPayment = this.paymentRepository.create(payment);
    return this.paymentRepository.save(newPayment);
  }

  async getPaymentById(paymentId: string): Promise<Payment> {
    return this.paymentRepository.findOne({ where: { id: paymentId } });
  }
}
