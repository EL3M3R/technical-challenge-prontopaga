import { Repository } from 'typeorm';
import { User, UserRole } from '../entities/user.entity';
import { InjectRepository } from '@nestjs/typeorm';

export class UserRepository {
  constructor(
    @InjectRepository(User) private readonly userRepository: Repository<User>,
  ) {}

  async findPatientById(id: string): Promise<User | null> {
    return this.userRepository.findOne({
      where: { id, role: UserRole.PATIENT },
    });
  }

  async findDoctorById(id: string): Promise<User | null> {
    return this.userRepository.findOne({
      where: { id, role: UserRole.DOCTOR },
    });
  }
}
